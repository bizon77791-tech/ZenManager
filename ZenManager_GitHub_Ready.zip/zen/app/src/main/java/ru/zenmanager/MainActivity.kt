package ru.zenmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZenManagerApp() }
    }
}

@Composable
fun ZenManagerApp() {
    var topic by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Готов к работе") }
    var post by remember { mutableStateOf("") }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Мой Дзен") })
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        "Личный ИИ-помощник для твоего дачного блога",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                item {
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("О чём следующий пост?") },
                        placeholder = { Text("Например: как мы сделали кухню") },
                        minLines = 3
                    )
                }
                item {
                    Button(
                        onClick = {
                            status = "Создаю черновик…"
                            post = if (topic.isBlank()) {
                                "Напиши тему поста — например: «Как мы сделали кухню на даче»."
                            } else {
                                "Тема: $topic\n\nЗдесь появится текст, который создаст ИИ."
                            }
                            status = "Черновик готов"
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✍ Создать пост")
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { status = "Выбор фотографий будет подключён следующим этапом" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📷 Добавить фотографии")
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { status = "Модуль публикации Дзен будет подключён следующим этапом" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🚀 Опубликовать в Дзен")
                    }
                }
                item {
                    Text("Статус: $status")
                }
                if (post.isNotBlank()) {
                    item {
                        HorizontalDivider()
                        Text(post, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
